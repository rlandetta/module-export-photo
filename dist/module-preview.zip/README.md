# Módulo de exportación fotográfica

Aplicación de escritorio web que permite a fotógrafos y editores preparar coberturas para agencias. Incluye tres módulos principales:

1. **Carga de imágenes** – arrastra o selecciona archivos, decide cuáles se exportarán y gestiona la lista de fotos.
2. **Edición de captions** – configura plantillas editoriales, personaliza títulos, lugar, fecha, agencia y créditos por imagen.
3. **Exportación** – genera un documento HTML con miniaturas y sube automáticamente las fotos seleccionadas más el documento a Google Drive.

La interfaz replica el flujo mostrado en las capturas de referencia y entrega un enlace compartible a la carpeta generada en Drive.

## Requisitos

- Node.js 18 o superior.
- Cuenta de Google con acceso a Google Drive.
- Credenciales OAuth 2.0 de tipo _web application_ creadas en Google Cloud Console.

## Configuración

1. Copia el archivo `.env.example` a `.env` y completa los valores:

   ```env
   GOOGLE_CLIENT_ID=tu-client-id
   GOOGLE_CLIENT_SECRET=tu-client-secret
   GOOGLE_REDIRECT_URI=http://localhost:5173/oauth2callback
   SESSION_SECRET=cadena-segura
   ```

   - El URI de redirección debe coincidir con la ruta configurada en Google Cloud. En desarrollo se usa `http://localhost:5173/oauth2callback`.

2. Instala las dependencias:

   ```bash
   npm install
   ```

3. Inicia el servidor en modo desarrollo:

   ```bash
   npm run dev
   ```

   El servidor levanta la interfaz en `http://localhost:5173`.

## Uso

1. Desde la interfaz, selecciona o arrastra imágenes al módulo de carga.
2. Configura los datos editoriales: título de cobertura, caption base, fecha, lugar, agencia, autor y editor.
3. Selecciona cada imagen para ajustar el nombre final y el caption. Puedes regenerarlo automáticamente con la plantilla.
4. Visualiza el documento en la sección *Preview*. El botón **Descargar documento** genera un HTML local con miniaturas.
5. Presiona **Conectar con Google Drive** y completa el flujo OAuth. Al finalizar, la aplicación mostrará que la sesión está lista.
6. Con la sesión activa, usa **Exportar a Google Drive**. El servidor creará una carpeta, subirá las imágenes y el documento HTML, y devolverá el enlace compartible.

> **Nota:** para funcionar en producción debes alojar el servidor en un dominio propio y registrar la URL en los orígenes autorizados de Google Cloud.

## Scripts disponibles

- `npm run dev` – inicia el servidor con reinicios automáticos (`nodemon`).
- `npm start` – levanta el servidor en modo producción.
- `npm test` – placeholder sin pruebas configuradas.
- `scripts/publish_to_github.sh` – automatiza la creación del repositorio público en tu cuenta de GitHub y realiza el primer push.

## Publicar en GitHub

Si ya tienes instalado [GitHub CLI](https://cli.github.com/) y has iniciado sesión con `gh auth login`, puedes crear el repositorio público y subir el código con:

```bash
scripts/publish_to_github.sh "module-v4" "Módulo de edición y exportación de imágenes para fotógrafos de agencias"
```

El script verificará que exista la autenticación activa, evitará sobreescribir remotos existentes y utilizará `gh repo create` para generar el repositorio público, configurarlo como `origin` y hacer el push inicial con el historial actual.

## Estructura del proyecto

```
public/        # Interfaz web (HTML, CSS y JS)
server/        # Servidor Express con integración Google Drive
.env.example   # Variables de entorno requeridas
```

## Seguridad

- Las credenciales OAuth nunca deben versionarse. Usa variables de entorno.
- El servidor mantiene los tokens de Google Drive en sesión. Para despliegues multiusuario se recomienda un almacén distribuido (Redis, Firestore, etc.).

## Limitaciones

- La subida a Google Drive requiere conectividad externa y credenciales válidas. En entornos sin acceso a Internet no funcionará.
- El botón de descarga genera un documento HTML. Si necesitas DOCX u otros formatos, se debe extender el servicio.

## Licencia

Este proyecto se entrega sin licencia explícita. Ajusta los términos según tus necesidades antes de distribuirlo.
